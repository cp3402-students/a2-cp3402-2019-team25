GRANT ALL PRIVILEGES ON scotchbox.* TO 'WebAdmin'@'localhost' IDENTIFIED BY 'gG5XCvUSL4keOwamsEz'
